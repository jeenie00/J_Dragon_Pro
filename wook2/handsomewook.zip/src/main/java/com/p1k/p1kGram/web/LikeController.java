package com.p1k.p1kGram.web;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

// RestController Controller + ResponseBody
// json 형태의 객체를 반환 시켜줌 
@RestController
public class LikeController {

}