package com.p1k.p1kGram.domain.user;

// 기본 roletype
public enum RoleType {
	USER, ADMIN
}