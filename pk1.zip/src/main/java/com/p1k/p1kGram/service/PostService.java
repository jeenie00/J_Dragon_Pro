package com.p1k.p1kGram.service;

public class PostService {

}
