package com.p1k.p1kGram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandsomewookApplicationTests {

	@Test
	void contextLoads() {
	}

}
